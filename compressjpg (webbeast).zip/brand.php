<?php
	$domainName = "CompressJPGOnline.com";
	$domainURL = "http://compressjpgonline.com";
	$icon_loc = "./img/icon.png";
	$main_title = "Compress JPG / JPEG Images Online for Free";  // Title of the Site
	
	$contact_email = "webbeastyt@gmail.com,";
?>